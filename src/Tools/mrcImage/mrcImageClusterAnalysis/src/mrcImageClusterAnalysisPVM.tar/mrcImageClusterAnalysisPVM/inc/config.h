#ifndef CONFIG_H
#define CONFIG_H

#include "../inc/mrcImageClusterAnalysisPVM.h"

#endif /* CONFIG_H */
