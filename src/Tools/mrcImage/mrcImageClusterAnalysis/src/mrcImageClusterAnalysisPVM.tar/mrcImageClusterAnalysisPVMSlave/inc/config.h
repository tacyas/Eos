#ifndef CONFIG_H
#define CONFIG_H

#include "../inc/mrcImageClusterAnalysisPVMSlave.h"

#endif /* CONFIG_H */
